# coding: utf-8
from .graphviz_wrapper import board


__author__  = "akimach"
__version__ = "0.0.6"
__license__ = "MIT"
